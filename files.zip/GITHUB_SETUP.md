# GitHub Setup Guide
## How to Upload This Project to GitHub

Follow these steps to get your project on GitHub for sharing with Daxwell.

---

## STEP 1: Create GitHub Repository

### Option A: Via GitHub Website (Easier)
1. Go to [github.com](https://github.com)
2. Click the "+" icon in top right → "New repository"
3. Repository details:
   - **Name**: `retail-analytics-sql`
   - **Description**: "SQL-based retail analytics system with customer behavior analysis, automated data pipelines, and data quality monitoring"
   - **Public** (so Daxwell can view it)
   - **DO NOT** initialize with README (we already have one)
4. Click "Create repository"

### Option B: Via GitHub CLI
```bash
gh repo create retail-analytics-sql --public --description "SQL-based retail analytics system"
```

---

## STEP 2: Initialize Git in Your Project

Open terminal/command prompt and navigate to your project folder:

```bash
# Navigate to project folder
cd /path/to/retail-analytics-sql

# Initialize git
git init

# Add all files
git add .

# Make first commit
git commit -m "Initial commit: Retail Analytics & Automation System"
```

---

## STEP 3: Connect to GitHub

Replace `yourusername` with your actual GitHub username:

```bash
# Add remote repository
git remote add origin https://github.com/yourusername/retail-analytics-sql.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### If You Get Authentication Errors:

You may need to create a Personal Access Token (PAT):

1. Go to GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Click "Generate new token (classic)"
3. Give it a name: "Retail Analytics Project"
4. Select scopes: Check "repo" (all sub-options)
5. Click "Generate token"
6. **SAVE THE TOKEN** - you won't see it again!
7. Use token as password when pushing

---

## STEP 4: Verify Upload

1. Go to `https://github.com/yourusername/retail-analytics-sql`
2. Verify all files are there:
   - README.md (displays on main page)
   - 4 SQL files
   - VIDEO_SCRIPT.md
   - GITHUB_SETUP.md (this file)

---

## STEP 5: Make Repository Stand Out

### Add Topics/Tags
On your GitHub repo page:
1. Click the gear icon next to "About"
2. Add topics:
   - `sql`
   - `data-analytics`
   - `mysql`
   - `stored-procedures`
   - `data-quality`
   - `business-intelligence`
   - `retail-analytics`

### Create a .gitignore (optional)
Create a file named `.gitignore`:
```
# Database files
*.sql~
*.swp

# OS files
.DS_Store
Thumbs.db

# IDE files
.vscode/
.idea/
```

### Add License (optional)
On GitHub:
1. Click "Add file" → "Create new file"
2. Name it `LICENSE`
3. GitHub will offer templates - choose "MIT License"
4. Commit the file

---

## STEP 6: Share the Link

Your repository link will be:
```
https://github.com/yourusername/retail-analytics-sql
```

**For Daxwell submission:**
- Share this exact link
- Make sure repository is **public**
- Verify README displays properly (shows up automatically)

---

## TROUBLESHOOTING

### Problem: "Permission denied (publickey)"
**Solution**: Use HTTPS instead of SSH:
```bash
git remote set-url origin https://github.com/yourusername/retail-analytics-sql.git
```

### Problem: "Repository not found"
**Solution**: Check spelling of username and repo name
```bash
git remote -v  # Shows current remote URL
```

### Problem: Large files won't upload
**Solution**: GitHub has 100MB file size limit
- This project's files are small, so this shouldn't be an issue
- If needed, use Git LFS for large files

### Problem: Changes not showing
**Solution**: 
```bash
git status  # Check what's staged
git log     # Check commit history
```

---

## ADDITIONAL TIPS

### Keep Your README Updated
As you make changes:
```bash
git add README.md
git commit -m "Update README with new findings"
git push
```

### Create a Professional Profile README
On your main GitHub page:
1. Create a repo named exactly as your username
2. Add a README.md there with your bio
3. This displays on your profile

### Add README Badges (Optional)
Add to top of README.md:
```markdown
![MySQL](https://img.shields.io/badge/MySQL-8.0+-blue)
![License](https://img.shields.io/badge/license-MIT-green)
```

---

## AFTER GITHUB UPLOAD: PREPARE FOR DAXWELL

### Create Your Submission Package:

1. **GitHub Repository Link**
   ```
   https://github.com/yourusername/retail-analytics-sql
   ```

2. **Video Recording**
   - Record 5-10 minute walkthrough
   - Upload to Dropbox folder with password: `InterviewDaxwell123@`
   - Use VIDEO_SCRIPT.md as your guide

3. **Quick Summary Document** (optional but recommended)
   Create a 1-page PDF with:
   - Project name
   - GitHub link
   - Video link
   - Key metrics (top 15% = 40%, 60% reduction, etc.)
   - Your contact info

---

## QUICK COMMAND REFERENCE

```bash
# Check status
git status

# Add changes
git add .

# Commit changes
git commit -m "Your message here"

# Push to GitHub
git push

# Pull latest changes
git pull

# View commit history
git log --oneline

# Create new branch (for experimenting)
git checkout -b feature-name
```

---

## FINAL CHECKLIST

Before submitting to Daxwell:
- [ ] Repository is public
- [ ] README displays correctly on GitHub
- [ ] All 4 SQL files are uploaded
- [ ] Code is readable (proper formatting)
- [ ] Repository has relevant topics/tags
- [ ] GitHub link is correct and accessible
- [ ] Video is recorded and uploaded to Dropbox
- [ ] Email with GitHub link and video sent to Daxwell

---

## Need Help?

- GitHub Guides: https://guides.github.com/
- GitHub Documentation: https://docs.github.com/
- Git Cheat Sheet: https://training.github.com/downloads/github-git-cheat-sheet.pdf

---

**You're all set! Good luck with your Daxwell submission!** 🚀
