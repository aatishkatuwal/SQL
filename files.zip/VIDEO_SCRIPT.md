# Video Walkthrough Script
## Retail Analytics & Automation System
### Duration: 8-10 minutes

---

## INTRODUCTION (1 minute)

**[Screen: Show GitHub repo]**

"Hi, I'm Aatish Katuwal, and today I'll walk you through my Retail Analytics and Automation project - a comprehensive SQL solution that analyzes 6 months of retail data to drive business insights.

**[Screen: Show README overview]**

This project demonstrates three key capabilities:
1. Advanced customer behavior analysis
2. Automated data management through stored procedures
3. A robust data quality framework

Let's dive in."

---

## PART 1: DATABASE ARCHITECTURE (2 minutes)

**[Screen: Open 01_database_setup.sql]**

"First, let me show you the database structure. I designed a normalized schema with five core tables:

**[Scroll through table definitions]**

- **Customers table**: Stores customer information including loyalty tiers
- **Products table**: 50 products across multiple categories with pricing and inventory
- **Orders table**: Transaction headers with status tracking
- **Order items**: Line-level detail for each order
- **Pricing history**: Tracks price changes over time for stale pricing detection

**[Scroll to data insertion section]**

I generated realistic sample data for 6 months - January through June 2024. This includes:
- 100 customers across Retail, Wholesale, and Corporate segments
- Different loyalty tiers: Platinum, Gold, Silver, and Bronze
- Over 400 orders with varying patterns to simulate real business behavior

**[Show indexes section]**

Notice I've also created indexes on frequently queried columns to optimize performance - this is critical for production systems."

---

## PART 2: CUSTOMER ANALYSIS (3 minutes)

**[Screen: Open 02_customer_analysis.sql]**

"Now for the analysis that drives the most business value.

**[Scroll to top 15% analysis]**

The key finding from this project is identifying that the top 15% of customers generate 40% of total revenue. Let me show you how I did this.

**[Highlight the WITH clause and window functions]**

I'm using Common Table Expressions and window functions to:
1. Rank customers by total revenue
2. Calculate their percentile
3. Sum the revenue contribution from the top 15%

**[Run the query if possible or show screenshot]**

The results show that just 15 customers out of 100 are driving almost half our revenue. This is crucial for:
- Targeting VIP loyalty programs
- Prioritizing customer service
- Allocating marketing budgets

**[Scroll to segment analysis]**

I also break down performance by customer segment and loyalty tier.

**[Show product analysis section]**

Moving to products, I identify:
- Top performers by revenue
- Slow-moving inventory that needs clearance
- Profit margins by category

**[Scroll to churn risk section]**

And importantly, I've built a churn risk analysis that identifies high-value customers who haven't ordered recently - these need immediate retention efforts."

---

## PART 3: AUTOMATION PROCEDURES (3 minutes)

**[Screen: Open 03_automation_procedures.sql]**

"One of my main goals was reducing manual work. I built 4 stored procedures that cut routine tasks by 60%.

**[Scroll to sp_cleanup_orders]**

**Procedure 1: Order Cleanup**
This removes duplicate orders, cleans up old cancelled transactions, and handles orphaned records.

**[Show the procedure logic]**

Notice it's wrapped in a transaction for data safety, and returns a summary of what was cleaned up.

**[Scroll to sp_apply_discount_logic]**

**Procedure 2: Dynamic Discount Logic**
This automatically calculates tiered discounts based on:
- Customer loyalty tier: Platinum gets 15%, Gold gets 10%, etc.
- Order value: Orders over $1000 get a bonus
- Lifetime value: Loyal customers get additional discounts

**[Highlight the business rules]**

The key here is that these business rules are codified in SQL, so they're applied consistently every time. No more manual discount calculations or inconsistencies.

**[Scroll to sp_detect_stale_pricing]**

**Procedure 3: Stale Pricing Detection**
This identifies products where pricing hasn't been updated in over 180 days.

**[Show the categorization logic]**

It categorizes them by urgency - Critical, High, or Medium - and generates actionable recommendations.

**[Scroll to sp_standardize_data]**

**Procedure 4: Data Standardization**
This formats everything consistently:
- Names in proper case
- Emails lowercase
- Phone numbers cleaned
- Prices rounded

**[Show the transformation examples]**

These small inconsistencies add up and cause reporting errors. This procedure eliminates them."

---

## PART 4: DATA QUALITY FRAMEWORK (2 minutes)

**[Screen: Open 04_data_quality_checks.sql]**

"Data quality is critical, so I built a comprehensive validation framework that reduced reporting errors by 20%.

**[Scroll to sp_run_data_quality_checks]**

The main procedure runs 5 categories of checks:

**[Show each check category briefly]**

1. **Missing Data**: Finds null or empty fields that should be populated
2. **Data Consistency**: Catches things like negative prices or invalid dates
3. **Business Rules**: Validates things like excessive discounts or zero-value orders
4. **Referential Integrity**: Ensures foreign keys are valid
5. **Anomaly Detection**: Flags outliers like unusually large orders or duplicate emails

**[Scroll to data_quality_log table]**

All issues are logged with severity levels - Critical, High, Medium, or Low.

**[Show the reporting views]**

And I've created views for easy reporting:
- Latest quality status
- Trends over time

**[Show example output or describe it]**

This gives management visibility into data health and helps prioritize fixes."

---

## PART 5: BUSINESS IMPACT & WRAP-UP (1 minute)

**[Screen: Back to README or create summary slide]**

"So to summarize the business impact:

**Key Metrics:**
- Identified revenue concentration: Top 15% = 40% of revenue
- Reduced manual work by 60% through automation
- Improved data accuracy by 20%
- Processed 400+ orders across 6 months

**Real-World Applications:**
This system can be adapted for:
- E-commerce platforms
- Retail chains
- B2B businesses
- Any company needing customer analytics

**[Show GitHub repo link]**

The full code is available on my GitHub with comprehensive documentation, and I'm happy to discuss how these techniques can be applied to your specific business needs.

**[Closing]**

Thanks for watching! Feel free to reach out if you have any questions."

---

## TECHNICAL TIPS FOR RECORDING

### Setup
- Use a clean MySQL Workbench or command line interface
- Have all 4 SQL files open in separate tabs
- Consider using syntax highlighting
- Set font size to at least 14pt for readability

### Recording Best Practices
- Use screen recording software (OBS Studio, Loom, or built-in)
- Record in 1920x1080 resolution minimum
- Speak clearly and at moderate pace
- Use cursor highlights or zoom for important code sections
- Pause briefly between sections

### What to Show on Screen
1. **GitHub repo** - Briefly at start and end
2. **SQL files** - Scroll through and highlight key sections
3. **Query execution** (if possible) - Show live results
4. **README** - Reference key metrics and findings

### What NOT to Do
- Don't read code line by line
- Don't go into syntax details (focus on business logic)
- Don't apologize or use filler words
- Don't spend time on minor errors (edit them out)

### Time Management
If running long, you can:
- Shorten the database setup section (30 seconds is enough)
- Combine procedures 3 and 4 explanation (1.5 minutes total)
- Skip showing every single query in detail

If running short, you can:
- Show actual query results / screenshots
- Demonstrate running a procedure live
- Discuss more business insights from the analysis
- Add more detail on future enhancements

---

## ALTERNATIVE STRUCTURE (if 5 minutes)

For a shorter 5-minute version:

1. **Intro** (30 sec): Project overview
2. **Key Finding** (90 sec): Show the 15% → 40% analysis only
3. **Automation** (90 sec): Show 2 procedures (discount logic + cleanup)
4. **Data Quality** (60 sec): Overview of validation framework
5. **Impact** (30 sec): Business metrics and wrap-up

---

## POST-VIDEO CHECKLIST

After recording:
- [ ] Review for audio quality
- [ ] Check that all code is readable
- [ ] Verify duration is 5-10 minutes
- [ ] Add captions if possible
- [ ] Export in high quality (1080p MP4)
- [ ] Test playback before uploading
- [ ] Upload to Dropbox folder with password: InterviewDaxwell123@
- [ ] Include GitHub link in video description or separate document

---

**Good luck with your recording! You've got this!** 🎥
